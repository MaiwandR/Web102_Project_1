import './App.css'
import Title from './components/Title'
import Card from './components/Card'
import batman from "./assets/batman.jpg"
import blood from "./assets/blood.avif"
import control from "./assets/control.webp"
import black from "./assets/black.webp"
import ghost  from "./assets/ghost.webp"
import human from "./assets/human.jpg"
import sek from "./assets/sek.jpg"
import son from "./assets/son.webp"
import spider from "./assets/spider.webp"
import war from "./assets/war.jpeg"
import ps_plus from "./assets/ps_plus.png"

const App = () => {

  return (
    <div className="App">

      <Title text = "Best Games on PS Plus" image={ps_plus}></Title>

      <div className="cards">

        <Card link = "https://store.playstation.com/en-us/concept/200089" name="Assassin's Creed IV: Black Flag" image={black} rating="8/10"></Card>
        <Card link = "https://store.playstation.com/en-us/concept/200520" name="Bloodborne: Remastered" image={blood} rating="7/10"></Card>
        <Card link = "https://store.playstation.com/en-us/concept/200472" name="Batman: Arkham Knight" image={batman} rating="8/10"></Card>
        <Card link = "https://store.playstation.com/en-us/concept/231819" name="Control: Ultimate Edition" image={control} rating="9/10"></Card>
        <Card link = "https://store.playstation.com/en-us/concept/235227" name="Ghost of Tsushima" image={ghost} rating="8/10"></Card>
        <Card link = "https://store.playstation.com/en-us/concept/222727" name="Detroit: Become Human" image={human} rating="10/10"></Card>
        <Card link = "https://www.playstation.com/en-us/games/sekiro-shadows-die-twice/" name="Sekiro: Shadows Die Twice" image={sek} rating="10/10"></Card>
        <Card link = "https://www.playstation.com/en-us/games/infamous-second-son/" name="Infamous: Second Son" image={son} rating="9/10"></Card>
        <Card link = "https://www.playstation.com/en-us/games/marvels-spider-man-remastered/" name="Marvel Spider-Man" image={spider} rating="10/10"></Card>
        <Card link = "https://store.playstation.com/en-us/concept/228618" name="God of War: Remastered" image={war} rating="9/10"></Card>
      </div>

    </div>
  )
}

export default App