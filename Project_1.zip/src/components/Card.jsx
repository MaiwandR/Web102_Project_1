import React from "react";



const Card = (props) => {

return (


    <>

        <div className="card">
            <img src={props.image} alt="game_image" />
            <div className="info">

                    <a href={props.link} target="_blank">

                    <h2>{props.name}</h2>
                    </a>

                    <p>{props.rating}</p>
            </div>
            
        </div>
    
    </>

)


}

export default Card