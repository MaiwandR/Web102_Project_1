import React from "react";


const Title = (props) => {


    return(

        <>
        
        <div className="top">

            <h2 className="title">{props.text}</h2>
            <img src={props.image} alt="ps_plus" />

        </div>
        </>
    )
}

export default Title